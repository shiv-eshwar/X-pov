# XProv-MAS — Springer Nature LaTeX package

This is a Springer Nature `sn-jnl` manuscript package using the official December 2024 journal article template, the numbered `sn-mathphys-num` bibliography style, and the `iicol` two-column option. The compiled manuscript is 10 A4 pages.

## Overleaf

1. Open Overleaf and choose **New Project → Upload Project**.
2. Upload the ZIP file containing this folder's source files.
3. Set `main.tex` as the main document if Overleaf does not select it automatically.
4. Compile with the default pdfLaTeX-compatible setting.

The package includes the class, bibliography style, bibliography database, figures, source, and a compiled PDF preview. `main.tex` is self-contained; no local `\input` files are required.

## Before submission

Replace the placeholder affiliation, organization, and email in the author block of `main.tex` with the final submission metadata. The page count may change slightly after that edit or if a journal requests a different Springer reference style.
